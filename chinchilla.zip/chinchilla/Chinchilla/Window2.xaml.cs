﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Research.DynamicDataDisplay;
using Microsoft.Research.DynamicDataDisplay.DataSources;

namespace Chinchilla
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private Dictionary<string, string> selectedPackage = new Dictionary<string, string>();
        Dictionary<string, string> pkginfo = new Dictionary<string, string>();
        List<Basechart> testchart = new List<Basechart>();

        public Window2()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            updateListview();
        }

        void updateListview()
        {
            pkginfo = DeviceInfoHelper.GetPackageInfo();

            foreach (KeyValuePair<string, string> pkg in pkginfo)
            {
                this.listView1.Items.Add(pkg.Key);
            }
        }

        private void listView1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedPackage.Clear();
            foreach(var item in this.listView1.SelectedItems)
            {
                selectedPackage[item.ToString()] = pkginfo[item.ToString()];
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (selectedPackage.Count == 0)
            {
                MessageBox.Show("Please select process");
            }
            else
            {
                testchart.Clear();
                testchart.Add(new DatausageChart(Dispatcher, this.chart_datausage, selectedPackage));
                testchart.Add(new CpuChart(Dispatcher, this.chart_cpu, selectedPackage));
                testchart.Add(new MemChart(Dispatcher, this.chart_mem, selectedPackage));
            }
        }
    }
}
