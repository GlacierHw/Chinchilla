﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using Microsoft.Research.DynamicDataDisplay;
using Microsoft.Research.DynamicDataDisplay.DataSources;
using System.Windows.Threading;

namespace Chinchilla
{
    class MemChart : Basechart
    {
        public override double getData(string package)
        {
            string meminfo;
            Executecmd.ExecuteCommandSync("adb shell dumpsys meminfo " + package, out meminfo);

            Regex memReg = new Regex(@".*TOTAL\s*(\d*)\s*");
            Match memM = memReg.Match(meminfo);
            if (memM.Groups.Count > 1)
            {
                return Convert.ToDouble(memM.Groups[1].ToString());
            }
            else
            {
                return -1;
            }
        }

        public MemChart(Dispatcher p, ChartPlotter newchart, Dictionary<string, string> packagelist)
            : base(p, newchart, packagelist)
        {
        }
    }
}
